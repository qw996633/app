var arr_wx =["gpmvp8.png","kppw362.png"];
var bq ="";
var wx_index = Math.floor((Math.random()*arr_wx.length));
var stxlwx = arr_wx[wx_index].replace(".jpg","").replace(".png","").replace(".jpeg","").replace(".gif","");
var wximg = "<img width='90%' src='"+arr_wx[wx_index]+"' />";