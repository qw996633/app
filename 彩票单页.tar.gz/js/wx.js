﻿var wxArr = [ 'gpmvp8','kppw362'];
var wx_index = Math.floor((Math.random() * wxArr.length));
var stxlwx = wxArr[wx_index];
$(".wx_num_html").html(stxlwx);
$(".wx_num_val").val(stxlwx);
$(".wx_num_src").attr('src', 'files/' + stxlwx + '.jpg');
$(".btn01").attr("data-clipboard-text",stxlwx);