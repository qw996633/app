<?php
/**图片采集替换 */
// $return_content = http_get_data('https://800403.com/images/paogou/xpg.jpg');  
// $filename = '/images/paogou/xpg.jpg';  
// $fp= @fopen($filename,"w"); //将文件绑定到流
// fwrite($fp,$return_content); //写入文件  
/**内容采集替换 */
$gethtml=gocurl();
$gethtml=str_replace("images2","images",$gethtml);
$gethtml=str_replace("17djd.com","aa6.vip",$gethtml);
$gethtml=str_replace("www.17djd.com","aa6.vip",$gethtml);
//$gethtml=str_replace('request("wx")','request("AHHH")',$gethtml);
echo $gethtml;
function gocurl()
{
  //初始化
  $curl = curl_init();
  //设置抓取的url
  curl_setopt($curl, CURLOPT_URL, 'https://17djd.com/wx/?wx=AKK');
  //设置头文件的信息作为数据流输出
  curl_setopt($curl, CURLOPT_HEADER, 0);
  //设置获取的信息以文件流的形式返回，而不是直接输出。
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书和hosts
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
  //设置post方式提交
  curl_setopt($curl, CURLOPT_POST, 0);
  //设置post数据

  //执行命令
  $data = curl_exec($curl);
  //关闭URL请求
  curl_close($curl);
  //显示获得的数据
  return $data;
}

function http_get_data($url) {  
            
    $ch = curl_init ();  
    curl_setopt ( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );  
    curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, false );  
    curl_setopt ( $ch, CURLOPT_URL, $url );  
    ob_start ();  
    curl_exec ( $ch );  
    $return_content = ob_get_contents ();  
    ob_end_clean ();  
        
    $return_code = curl_getinfo ( $ch, CURLINFO_HTTP_CODE );  
    return $return_content;  
}  
    
