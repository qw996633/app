<?php

$wxstr=[wgf511600,wgf511600];
$QQ=[188621,188621];
/**内容采集替换 */
$gethtml=gocurl();
$gethtml=str_replace("images2","images",$gethtml);
$gethtml=str_replace("17djd.com","aa6.vip",$gethtml);
$gethtml=str_replace("www.17djd.com","aa6.vip",$gethtml);
$gethtml=str_replace("/wx/?wx=","/wx.html?wx=",$gethtml);
$gethtml=str_replace("/wx/qq.html?wx=","/qq.html?wx=",$gethtml);


preg_match_all("/\[\"[a-zA-Z0-9]+\",\"[a-zA-Z0-9]+\"\]/i",$gethtml, $wxall);
preg_match_all("/\[\"[a-zA-Z0-9]+\.jpg\",\"[a-zA-Z0-9]+\.jpg\"]/i",$gethtml, $wxajgp);
preg_match_all("/\"https\:\/\/hm\.baidu\.com\/hm\.js\?[a-zA-Z0-9]+\"/i",$gethtml, $baidump);

preg_match_all("/\<script(.*)type\=\"text\/javascript\"(.*)src\=\"\/images\/jquery\.easing\.min\.js\"\>\<\/script\>/i",$gethtml, $addjs);



preg_match_all("/\/qq.html\?wx\=([a-zA-Z0-9]+)\s\"/i",$gethtml, $qq);
$gethtml=str_replace($qq[1][0],$QQ[array_rand($QQ,1)],$gethtml);

$gethtml=str_replace($baidump[0][0],'',$gethtml);
$gethtml=str_replace($wxall[0][0],"['wgf511600','wgf511600']",$gethtml);
$gethtml=str_replace($wxajgp[0][0],"['svipm66.jpg','svipm66.jpg']",$gethtml);
$gethtml=str_replace('src="/images/main.js"','src="http://js.users.51.la/20144219.js"',$gethtml);
//马上联系美女客服
$gethtml=str_replace("马上联系美女客服","马上联系微信客服",$gethtml);
echo $gethtml;

function gocurl()
{
  //初始化
  $curl = curl_init();
  //设置抓取的url
  curl_setopt($curl, CURLOPT_URL, 'https://w1221.com/');
  //设置头文件的信息作为数据流输出
  curl_setopt($curl, CURLOPT_HEADER, 0);
  //设置获取的信息以文件流的形式返回，而不是直接输出。
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书和hosts
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
  //设置post方式提交
  curl_setopt($curl, CURLOPT_POST, 0);
  //设置post数据

  //执行命令
  $data = curl_exec($curl);
  //关闭URL请求
  curl_close($curl);
  //显示获得的数据
  return $data;
}

function http_get_data($url) {  
            
    $ch = curl_init ();  
    curl_setopt ( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );  
    curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, false );  
    curl_setopt ( $ch, CURLOPT_URL, $url );  
    ob_start ();  
    curl_exec ( $ch );  
    $return_content = ob_get_contents ();  
    ob_end_clean ();  
        
    $return_code = curl_getinfo ( $ch, CURLINFO_HTTP_CODE );  
    return $return_content;  
}